package com.example.luciferr.sobatlepi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Rekomendasi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rekomendasi);
    }
    public void rekom(View v){
        Intent rek = new Intent(Rekomendasi.this, ListRekomendasi.class);
        startActivity(rek);
    }
}
